//
//  MainTVC.m
//  BigO
//
//  Created by Michalis Mavris on 10/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "MainTVC.h"

@implementation MainTVC{

    NSInteger cellPressed;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    switch (indexPath.row) {
        case 0:
            [self performSegueWithIdentifier:@"toCrimeMenuTVC" sender:self];
            break;
        case 1:
            [self performSegueWithIdentifier:@"toWeatherMenuTVC" sender:self];
            break;
        default:
            break;
    }

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {

}
@end
