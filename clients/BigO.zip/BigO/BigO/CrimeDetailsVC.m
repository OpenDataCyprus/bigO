//
//  CrimeDetailsVC.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "CrimeDetailsVC.h"
#import "CrimeDetailsCell.h"
#import "CrimeDetails.h"

@implementation CrimeDetailsVC

#pragma mark - UITableView Delegates
-(void)viewDidLoad {

    self.percentageLabel.text= [NSString stringWithFormat:@"Percentage:%@",self.total.crimePercentage];
    self.crimeLabel.text= [NSString stringWithFormat:@"Crimes:%@",self.total.crimeK];
    self.solvedCrimesLabel.text= [NSString stringWithFormat:@"Solved:%@",self.total.crimeE];

}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [self.citiesArray count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *tableIdentifier = @"CrimeDetailsCell";
    
    CrimeDetailsCell *cell = (CrimeDetailsCell*)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    
    if (cell == nil) {
        cell = [[CrimeDetailsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableIdentifier];
    }
    
    CrimeDetails *crimeDetails = [self.citiesArray objectAtIndex:indexPath.row];
    
    [cell.title setText:crimeDetails.crimeTitle];
    [cell.crimesNumber setText:[NSString stringWithFormat:@"Crimes:%@",crimeDetails.crimeK]];
    [cell.crimesSolved setText:[NSString stringWithFormat:@"Solved:%@",crimeDetails.crimeE]];
    [cell.crimesSolvedPercentage setText:[NSString stringWithFormat:@"Percentage:%@",crimeDetails.crimePercentage]];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


@end
