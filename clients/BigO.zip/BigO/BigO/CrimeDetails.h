//
//  CrimeDetails.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CrimeDetails : NSObject
@property (nonatomic,strong)NSString *crimeTitle;
@property (nonatomic,strong)NSString *crimeK;
@property (nonatomic,strong)NSString *crimeE;
@property (nonatomic,strong)NSString *crimePercentage;
-(instancetype)initWithDictionary:(NSDictionary*)dict;
@end
