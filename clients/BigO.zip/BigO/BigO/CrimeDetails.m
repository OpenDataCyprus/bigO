//
//  CrimeDetails.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "CrimeDetails.h"

@implementation CrimeDetails {

}
-(instancetype)initWithDictionary:(NSDictionary*)dict {

    self = [super init];
    
    if (self) {
        
        self.crimeK = [dict objectForKey:@"K"];
        self.crimeE = [dict objectForKey:@"E"];
        self.crimePercentage = [dict objectForKey:@"percentage"];
        self.crimeTitle = [dict objectForKey:@"name"];
    }
    
    return  self;
}
@end
