//
//  CrimeMenuTVC.h
//  BigO
//
//  Created by Michalis Mavris on 10/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CrimeMenuTVC : UITableViewController

@end
