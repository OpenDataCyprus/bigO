//
//  Crime.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "Crime.h"

@implementation Crime
-(instancetype)initWithDictionary:(NSDictionary*)dict {

    self = [super init];
    
    if (self) {
    
        self.crime = [dict objectForKey:@"name"];
        self.crimesTotal = [[CrimeDetails alloc]initWithDictionary:[dict objectForKey:@"totals"]];
        self.cities = [[NSMutableArray alloc]init];
        
        self.currentCities = [dict objectForKey:@"cities"];
        
        for (NSDictionary *dict in self.currentCities) {
            
            CrimeDetails *curDetails = [[CrimeDetails alloc]initWithDictionary:dict];
            [self.cities addObject:curDetails];
        }
    }
    
    return  self;
}
@end
