//
//  WeatherDetailsVC.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RequestController.h"

@interface WeatherDetailsVC : UIViewController <RequestControllerDelegate>
@property (weak, nonatomic) IBOutlet UINavigationItem *navTitle;
@property (weak, nonatomic) IBOutlet UILabel *cityLabel;
@property (weak, nonatomic) IBOutlet UILabel *temperatureLabel;

@property (weak, nonatomic) IBOutlet UILabel *windSpeedLabel;
@property (weak, nonatomic) IBOutlet UILabel *slpLabel;

@property (nonatomic,assign)NSInteger type;

@end
