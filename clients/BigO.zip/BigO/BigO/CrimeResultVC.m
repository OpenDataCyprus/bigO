//
//  CrimeResultVC.m
//  BigO
//
//  Created by Michalis Mavris on 10/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "CrimeResultVC.h"
#import "RequestController.h"
#import "Crime.h"
#import "CrimeCell.h"
#import "CrimeDetailsVC.h"
#import "SVProgressHUD.h"

@interface CrimeResultVC ()
@property (nonatomic,strong)NSArray *crimesArray;
@end

@implementation CrimeResultVC {

    NSInteger cellPressed;
}

-(void)viewDidLoad {

    switch (self.type) {
        case 0:
            [self.navTitle setTitle:@"Minor Crimes"];
            break;
        case 1:
            [self.navTitle setTitle:@"Major Crimes"];
            break;
        case 2:
            [self.navTitle setTitle:@"All Crimes"];
            break;
        default:
            break;
    }
    
    [SVProgressHUD showWithStatus:@"Loading data.."];
    
    RequestController *req;
    req= [[RequestController alloc]initAndDownloadMinorCrimesWithDelegate:self];
    
}

-(void)RequestControllerRequestSuccessfulWithResult:(NSArray *)crimeArray {

    self.crimesArray= crimeArray;
    [self.tableV reloadData];
    [SVProgressHUD dismiss];

}

-(void)RequestControllerRequestFailedWithError:(NSInteger)RCError {

    [SVProgressHUD dismiss];

};

#pragma mark - UITableView Delegates

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [self.crimesArray count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *tableIdentifier = @"CrimeCell";
    
    CrimeCell *cell = (CrimeCell*)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    
    if (cell == nil) {
        cell = [[CrimeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableIdentifier];
    }
    
    Crime *crime = [self.crimesArray objectAtIndex:indexPath.row];
    
    [cell.crimeLabel setText:crime.crime];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    cellPressed=indexPath.row;
    
    [self performSegueWithIdentifier:@"toCrimeDetailsVC" sender:nil];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
        
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {

    if ([[segue identifier] isEqualToString:@"toCrimeDetailsVC"]) {
        
        Crime *crime = [self.crimesArray objectAtIndex:cellPressed];
        CrimeDetailsVC *crVC = [segue destinationViewController];
        crVC.citiesArray = crime.cities;
        crVC.total = crime.crimesTotal;
    }
}
@end
