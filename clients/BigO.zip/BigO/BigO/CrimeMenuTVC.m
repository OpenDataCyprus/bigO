//
//  CrimeMenuTVC.m
//  BigO
//
//  Created by Michalis Mavris on 10/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "CrimeMenuTVC.h"
#import "CrimeResultVC.h"

@implementation CrimeMenuTVC {

    NSInteger cellPressed;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    cellPressed = indexPath.row;
    [self performSegueWithIdentifier:@"toCrimeResultVC" sender:self];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    CrimeResultVC *crVC = [segue destinationViewController];
    crVC.type = cellPressed;

}

@end
