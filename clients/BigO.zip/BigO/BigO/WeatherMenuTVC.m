//
//  WeatherMenuTVC.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "WeatherMenuTVC.h"
#import "WeatherDetailsVC.h"

@implementation WeatherMenuTVC{

    NSInteger cellPressed;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cellPressed = indexPath.row;
    
    [self performSegueWithIdentifier:@"toWeatherDetailsVC" sender:self];

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    WeatherDetailsVC *wdVC = [segue destinationViewController];
    wdVC.type =cellPressed;
    
}
@end
