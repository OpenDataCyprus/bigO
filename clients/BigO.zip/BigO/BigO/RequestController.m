//
//  RequestController.m
//  BigO
//

#import "RequestController.h"

//We use constant to keep the URL. In the future when we will have more than 1 request we can change the URL for all requests from here.

@implementation RequestController{
    NSURLConnection *conn;
    NSArray *responseArray;
    NSMutableData *responseData;
    NSInteger currentMode;
}
@synthesize delegate;

#pragma mark - Init Functions
-(id)initAndDownloadMinorCrimesWithDelegate:(id<RequestControllerDelegate>)del {
    self = [super init];
    
    if (self) {
        
        currentMode=0;
        
        [self setDelegate:del];
        
        //Check for internet connection
        BOOL internet = [self internetConnectivity];
        
        //Sending the requests on the server
        if(internet){
            
            
            //DSLog(@"time stamp %@",updateTimestamp);
            
            NSString* url = @"http://82.196.12.250/api/crimes";
            
            //DSLog(@"url %@",url);
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:3];
        
            //DSLog(@"%@",param);

           // NSData *requestBodyData = [param dataUsingEncoding:NSUTF8StringEncoding];
            //request.HTTPBody = requestBodyData;
            request.HTTPMethod = @"GET";
            
            conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
            [conn start];
        }
        
        else{
            
            NSInteger errorMode =10;

            [delegate RequestControllerRequestFailedWithError:errorMode];
        }
    }
    return self;
    
}

-(id)initAndDownloadMajorCrimesWithDelegate:(id<RequestControllerDelegate>)del {
    self = [super init];
    
    if (self) {
        
        currentMode=0;
        
        [self setDelegate:del];
        
        //Check for internet connection
        BOOL internet = [self internetConnectivity];
        
        //Sending the requests on the server
        if(internet){
            
            
            //DSLog(@"time stamp %@",updateTimestamp);
            
            NSString* url = @"http://82.196.12.250/storage/minorCrimes.json";
            
            //DSLog(@"url %@",url);
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:3];
            
            //DSLog(@"%@",param);
            
            // NSData *requestBodyData = [param dataUsingEncoding:NSUTF8StringEncoding];
            //request.HTTPBody = requestBodyData;
            request.HTTPMethod = @"GET";
            
            conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
            [conn start];
        }
        
        else{
            
            NSInteger errorMode =10;
            
            [delegate RequestControllerRequestFailedWithError:errorMode];
        }
    }
    return self;
    
}

-(id)initAndDownloadAllCrimesWithDelegate:(id<RequestControllerDelegate>)del {
    self = [super init];
    
    if (self) {
        
        currentMode=0;
        
        [self setDelegate:del];
        
        //Check for internet connection
        BOOL internet = [self internetConnectivity];
        
        //Sending the requests on the server
        if(internet){
            
            
            //DSLog(@"time stamp %@",updateTimestamp);
            
            NSString* url = @"";
            
            //DSLog(@"url %@",url);
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:3];
            
            //DSLog(@"%@",param);
            
            // NSData *requestBodyData = [param dataUsingEncoding:NSUTF8StringEncoding];
            //request.HTTPBody = requestBodyData;
            request.HTTPMethod = @"GET";
            
            conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
            [conn start];
        }
        
        else{
            
            NSInteger errorMode =10;
            
            [delegate RequestControllerRequestFailedWithError:errorMode];
        }
    }
    return self;
    
}
-(id)initAndDownloadWeatherFor:(NSString*)city :(id<RequestControllerDelegate>)del {
    self = [super init];
    
    if (self) {
        
        currentMode=1;
        
        [self setDelegate:del];
        
        //Check for internet connection
        BOOL internet = [self internetConnectivity];
        
        //Sending the requests on the server
        if(internet){
            
            
            //DSLog(@"time stamp %@",updateTimestamp);
            
            NSString* url =[NSString stringWithFormat:@"http://82.196.12.250/api/weather/city/%@",city];
            
            //DSLog(@"url %@",url);
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:3];
            
            //DSLog(@"%@",param);
            
            // NSData *requestBodyData = [param dataUsingEncoding:NSUTF8StringEncoding];
            //request.HTTPBody = requestBodyData;
            request.HTTPMethod = @"GET";
            
            conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
            [conn start];
        }
        
        else{
            
            NSInteger errorMode =10;
            
            [delegate RequestControllerRequestFailedWithError:errorMode];
        }
    }
    return self;
    
}

#pragma mark - Delegates for NSURLConnection
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    // A response has been received, this is where we initialize the instance var you created
    // so that we can append data to it in the didReceiveData method
    // Furthermore, this method is called each time there is a redirect so reinitializing it
    // also serves to clear it
    responseData = [[NSMutableData alloc] init];
    
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
    NSInteger code = [httpResponse statusCode];
    
    if (code!=200) {
        
        [delegate RequestControllerRequestFailedWithError:11];
        
        [connection cancel];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    // Append the new data to the instance variable you declared
    
    [responseData appendData:data];
    
    NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    NSLog(@"%@",responseString);
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
    return nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    [connection cancel];
    
    if (currentMode==0) {
        [self parseJSONFor:0];

    }
    else {
        [self parseJSONFor1:0];

    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
    [delegate RequestControllerRequestFailedWithError:11];
}

#pragma mark - Parse method

-(void)parseJSONFor:(NSInteger)mode{
    
    self.resultArray = [[NSMutableArray alloc]init];
    
    NSError *jsonParsingError=nil;
    
    //Converting the JSON data to a Dictionary
    NSDictionary *allDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:&jsonParsingError];
    
    if (jsonParsingError) {
        //In case the JSON is invalid we call the failed delegate
        [delegate RequestControllerRequestFailedWithError:11];
        
        return;
    }
    
    
    //Converting the "Companies" or "Categories" or "Locations" object to an array so we can iterate and get all the values
    responseArray = [allDictionary objectForKey:@"data"];
    
    NSMutableArray *crimeArray = [[NSMutableArray alloc]init];
    
    for (NSDictionary *dict in responseArray) {
        Crime *cr = [[Crime alloc]initWithDictionary:dict];
        [crimeArray addObject:cr];
    }
    //Looping through the array and creating the objects Company and adding them on a new array that will hold the objects
    
    [delegate RequestControllerRequestSuccessfulWithResult:crimeArray];
}
-(void)parseJSONFor1:(NSInteger)mode{
    
    self.resultArray = [[NSMutableArray alloc]init];
    
    NSError *jsonParsingError=nil;
    
    //Converting the JSON data to a Dictionary
    NSDictionary *allDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:&jsonParsingError];
    
    if (jsonParsingError) {
        //In case the JSON is invalid we call the failed delegate
        [delegate RequestControllerRequestFailedWithError:11];
        
        return;
    }
    
   
    responseArray = [allDictionary objectForKey:@"data"];
    
    Weather *weather = [[Weather alloc]initWithDict:[responseArray lastObject]];
    
    NSMutableArray *weatherArray = [[NSMutableArray alloc]initWithObjects:weather, nil];
    
       //Looping through the array and creating the objects Company and adding them on a new array that will hold the objects
    
    
    [delegate RequestControllerRequestSuccessfulWithResult:weatherArray];
}

#pragma mark - Internet Connectivity method
//Check the internet connectivity
-(BOOL)internetConnectivity{
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    
    if (networkStatus == NotReachable) {
        
        return FALSE;
    }
    else
    {
        return TRUE;
    }
    
}
@end
