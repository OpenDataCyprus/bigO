//
//  Weather.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weather : NSObject

@property (nonatomic,strong)NSString *temp;
@property (nonatomic,strong)NSString *windSpeed;
@property (nonatomic,strong)NSString *slp;

-(instancetype)initWithDict:(NSDictionary*)dict;

@end
