//
//  Crime.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CrimeDetails.h"

@interface Crime : NSObject
@property (nonatomic,strong)NSString *crime;
@property (nonatomic,strong)CrimeDetails *crimesTotal;
@property (nonatomic,strong)NSMutableArray *cities;
@property (nonatomic,strong)NSArray *currentCities;
-(instancetype)initWithDictionary:(NSDictionary*)dict;
@end
