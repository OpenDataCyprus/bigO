//
//  CrimeDetailsCell.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CrimeDetailsCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *crimesNumber;
@property (weak, nonatomic) IBOutlet UILabel *crimesSolved;
@property (weak, nonatomic) IBOutlet UILabel *crimesSolvedPercentage;

@end
