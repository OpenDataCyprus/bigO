//
//  CrimeDetailsVC.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CrimeDetails;

@interface CrimeDetailsVC : UIViewController <UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableV;
@property (weak, nonatomic) IBOutlet UINavigationItem *navTitle;
@property (nonatomic,strong)NSArray *citiesArray;
@property (nonatomic,strong)CrimeDetails *total;
@property (weak, nonatomic) IBOutlet UILabel *crimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *percentageLabel;

@property (weak, nonatomic) IBOutlet UILabel *solvedCrimesLabel;
@end
