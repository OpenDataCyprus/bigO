//
//  Weather.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "Weather.h"

@implementation Weather
-(instancetype)initWithDict:(NSDictionary*)dict {

    self = [super init];
    
    if (self) {
        self.temp = [dict objectForKey:@"temp"];
        self.windSpeed =[dict objectForKey:@"sw"];
        self.slp = [dict objectForKey:@"net"];
    }
    
    return  self;
}
@end
