//
//  RequestController.h
//  BigO


#import <Foundation/Foundation.h>
#import "Reachability.h"
#import "Crime.h"
#import "Weather.h"

//================

@protocol RequestControllerDelegate <NSObject>

@required
/*! 
 @brief The delegate that called when the request is successfull
 @param mode The mode that was used to call the RequestController
 */
-(void)RequestControllerRequestSuccessfulWithResult:(NSArray*)crimeArray;

/*!
 @brief The delegate that called when the request is failed
 @param RCError The error that caused the method to failed
 */
- (void)RequestControllerRequestFailedWithError:(NSInteger)RCError;
@end

//=================



@interface RequestController : NSObject <NSURLConnectionDataDelegate>

@property (nonatomic, assign) id <RequestControllerDelegate> delegate;

@property(nonatomic,strong)NSMutableArray *resultArray;

/*!
 @brief This method downloads all the data that the application needs
 @params lang The language of the requested data. eg. "en"
 @params force If force=YES it will force download all data ignoring the "last update" property
 @parms delegate The delegate that delegate methods will executed
 */
-(id)initAndDownloadMinorCrimesWithDelegate:(id<RequestControllerDelegate>)del;
-(id)initAndDownloadMajorCrimesWithDelegate:(id<RequestControllerDelegate>)del;
-(id)initAndDownloadAllCrimesWithDelegate:(id<RequestControllerDelegate>)del;
-(id)initAndDownloadWeatherFor:(NSString*)city :(id<RequestControllerDelegate>)del;
@end