//
//  CrimeDetailsCell.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "CrimeDetailsCell.h"

@implementation CrimeDetailsCell

@end
