//
//  CrimeCell.h
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CrimeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *crimeLabel;

@end
