//
//  WeatherDetailsVC.m
//  BigO
//
//  Created by Michalis Mavris on 11/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "WeatherDetailsVC.h"
#import "Weather.h"
#import "SVProgressHUD.h"

@implementation WeatherDetailsVC

-(void)viewDidLoad {

    [SVProgressHUD showWithStatus:@"Loading data.."];
    RequestController *req;
    
    
    if (self.type==0) {
        
        req = [[RequestController alloc]initAndDownloadWeatherFor:@"athalassa" :self];

    }
    else {
        req = [[RequestController alloc]initAndDownloadWeatherFor:@"larnaka" :self];

    }
    
}

-(void)RequestControllerRequestSuccessfulWithResult:(NSArray *)crimeArray {

    Weather *weather = [crimeArray firstObject];
    
    if (self.type==0) {
        [self.cityLabel setText:@"City: Nicosia"];

    }
    else if (self.type==1) {
        [self.cityLabel setText:@"City: Larnaca"];
        
    }
    
    [self.temperatureLabel setText:[NSString stringWithFormat:@"Temperature: %@C",weather.temp]];
    [self.windSpeedLabel setText:[NSString stringWithFormat:@"Wind Speed: %@",weather.windSpeed]];
    [self.slpLabel setText:[NSString stringWithFormat:@"SLP: %@",weather.slp]];

    [SVProgressHUD dismiss];

}

-(void)RequestControllerRequestFailedWithError:(NSInteger)RCError {
    [SVProgressHUD dismiss];

}

@end
