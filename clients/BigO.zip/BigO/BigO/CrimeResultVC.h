//
//  CrimeResultVC.h
//  BigO
//
//  Created by Michalis Mavris on 10/09/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RequestController.h"

@interface CrimeResultVC : UIViewController <RequestControllerDelegate,UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableV;
@property (nonatomic,assign)NSInteger type;
@property (weak, nonatomic) IBOutlet UINavigationItem *navTitle;
@end
